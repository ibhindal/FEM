# FEM
This is the code respiritory for group 4 FEA module. 

This program analyses the stress field in a 2D representation of a hip replacement.

This code has been tested in Python 3.10.8

Required Modules and their tested versions
- numpy
- scipy
-meshio
-matplotlib
- ...
Input files used to test program
- simpleMod.geo
- simpleMod.vsh
- ...







----------------------------------------------------------------------------------------
To do list
- 





